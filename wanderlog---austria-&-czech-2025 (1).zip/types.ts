
export enum ItemType {
  FLIGHT = 'FLIGHT',
  HOTEL = 'HOTEL',
  TRANSPORT = 'TRANSPORT',
  ATTRACTION = 'ATTRACTION',
  FOOD = 'FOOD',
  SHOPPING = 'SHOPPING',
  OTHER = 'OTHER',
}

export interface AIGuideInfo {
  story?: string;
  tips?: string[];
  weather?: string;
  highlight?: boolean;
}

export interface ItineraryItem {
  id: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:mm
  type: ItemType;
  title: string;
  location: string;
  region?: string;
  openTime?: string;
  description?: string;
  relatedTodoIds?: string[];
  relatedShoppingIds?: string[];
  notes?: string;
  guideInfo?: AIGuideInfo;
}

// 待辦事項 (Todo)
export interface TodoItem {
  id: string;
  text: string;
  completed: boolean;
  completedDate?: string; // YYYY-MM-DD
  relatedItineraryId?: string; // Link to specific trip event
}

// 行李清單 (Packing)
export interface PackingItem {
  id: string;
  text: string;
  category: string; // e.g., 'clothes', '3c'
  isPacked: boolean;
  baggageType: 'carry_on' | 'checked'; // 隨身 vs 託運
  note?: string;
}

// 支出 (Expenses) - Detailed
export interface ExpenseItem {
  id: string;
  date: string; // 支付日期
  category: string; // 類型
  paymentMethod: string; // 卡別/現金
  
  // Amounts
  amountEUR?: number;
  feeEUR?: number;
  amountCZK?: number;
  feeCZK?: number;
  amountTWD?: number;
  feeTWD?: number;
  
  totalTWD: number; // 台幣總額
  
  isReconciled: boolean; // 對帳
  timing: 'pre_trip' | 'local'; // 行前 vs 當地
  note?: string;
}

export interface AppState {
  itinerary: ItineraryItem[];
  todos: TodoItem[];
  shopping: TodoItem[];
  packing: PackingItem[];
  expenses: ExpenseItem[];
}
