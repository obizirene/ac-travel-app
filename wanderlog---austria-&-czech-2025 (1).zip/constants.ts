
import { ItineraryItem, ItemType, TodoItem, PackingItem } from './types';

export const REGION_OPTIONS = [
  { id: 'moving', label: '移動', color: 'bg-orange-200 text-orange-800' },
  { id: 'prague', label: '布拉格', color: 'bg-red-200 text-red-900' },
  { id: 'kutna_hora', label: '庫特納霍拉', color: 'bg-amber-200 text-amber-800' },
  { id: 'ck', label: '克魯姆洛夫', color: 'bg-green-200 text-green-800' },
  { id: 'vienna', label: '維也納', color: 'bg-purple-200 text-purple-800' },
  { id: 'hallstatt', label: '哈修塔特', color: 'bg-stone-200 text-stone-800' },
  { id: 'salzburg', label: '薩爾茲堡', color: 'bg-pink-200 text-pink-800' },
  { id: 'konigssee', label: '國王湖', color: 'bg-slate-200 text-slate-800' },
  { id: 'taiwan', label: '台灣', color: 'bg-blue-200 text-blue-800' },
];

export const TYPE_OPTIONS = [
  { id: ItemType.FLIGHT, label: '✈️ 航班', icon: '✈️' },
  { id: ItemType.TRANSPORT, label: '🚆 交通', icon: '🚆' },
  { id: ItemType.HOTEL, label: '🏨 飯店', icon: '🏨' },
  { id: ItemType.ATTRACTION, label: '🌲 景點', icon: '🌲' },
  { id: ItemType.FOOD, label: '🍽️ 正餐', icon: '🍽️' },
  { id: ItemType.OTHER, label: '☕ 咖啡廳', icon: '☕' },
  { id: ItemType.SHOPPING, label: '🛍️ 購物', icon: '🛍️' },
];

// Packing Categories
export const PACKING_CATEGORIES = [
  { id: 'clothes', label: '衣物', color: 'bg-rose-100 text-rose-700' },
  { id: 'accessories', label: '配件', color: 'bg-pink-100 text-pink-700' },
  { id: 'toiletries', label: '盥洗用品', color: 'bg-amber-100 text-amber-700' },
  { id: 'cosmetics', label: '化妝品', color: 'bg-red-100 text-red-700' },
  { id: '3c', label: '3C用品', color: 'bg-blue-100 text-blue-700' },
  { id: 'personal', label: '個人用品', color: 'bg-sky-100 text-sky-700' },
  { id: 'care', label: '保養品', color: 'bg-emerald-100 text-emerald-700' },
  { id: 'other', label: '其他', color: 'bg-gray-100 text-gray-700' },
];

export const EXPENSE_CATEGORIES = [
  { id: 'food', label: '餐飲' },
  { id: 'transport', label: '交通' },
  { id: 'shopping', label: '購物' },
  { id: 'accommodation', label: '住宿' },
  { id: 'ticket', label: '門票' },
  { id: 'other', label: '其他' },
];

export const PAYMENT_METHODS = [
  { id: 'cash', label: '現金' },
  { id: 'credit_card', label: '信用卡' },
  { id: 'debit_card', label: '簽帳卡' },
];

// Pre-parsed data
export const INITIAL_ITINERARY: ItineraryItem[] = [
  // Dec 5
  { id: '1', date: '2025-12-05', time: '23:00', type: ItemType.FLIGHT, title: '起飛｜桃園機場', location: 'Taoyuan International Airport', region: 'taiwan' },
  // Dec 6
  { id: '2', date: '2025-12-06', time: '06:45', type: ItemType.FLIGHT, title: '降落｜維也納機場', location: 'Vienna International Airport', region: 'vienna' },
  { id: '3', date: '2025-12-06', time: '10:33', type: ItemType.TRANSPORT, title: '火車｜維也納機場 > 布拉格 (RJ640+RJ74)', location: 'Vienna Airport Train Station', region: 'moving' },
  { id: '4', date: '2025-12-06', time: '16:00', type: ItemType.ATTRACTION, title: '聖盧德米拉教堂', location: 'Church of Saint Ludmila, Prague', region: 'prague' },
  { id: '5', date: '2025-12-06', time: '17:00', type: ItemType.FOOD, title: '冰淇淋｜Amorino Gelato', location: 'Amorino Gelato - Praha', region: 'prague' },
  { id: '6', date: '2025-12-06', time: '17:30', type: ItemType.FOOD, title: '餐廳｜Restaurace Mlejnice', location: 'Restaurace Mlejnice', region: 'prague' },
  { id: '7', date: '2025-12-06', time: '19:00', type: ItemType.ATTRACTION, title: '聖誕市集｜老城廣場', location: 'Old Town Square, Prague', region: 'prague' },
  { id: '8', date: '2025-12-06', time: '21:00', type: ItemType.FOOD, title: '餐廳｜Terasa U Prince', location: 'Terasa U Prince', region: 'prague' },
  { id: '9', date: '2025-12-06', time: '22:00', type: ItemType.HOTEL, title: '入住｜Prague Season Hotel', location: 'Prague Season Hotel', region: 'prague' },
  // Dec 7
  { id: '10', date: '2025-12-07', time: '07:00', type: ItemType.TRANSPORT, title: '火車｜Season Hotel > 庫特納霍拉', location: 'Kutná Hora', region: 'moving' },
  { id: '11', date: '2025-12-07', time: '09:00', type: ItemType.FOOD, title: '咖啡店｜Coffeehood', location: 'Coffeehood, Kutná Hora', region: 'kutna_hora' },
  { id: '12', date: '2025-12-07', time: '10:00', type: ItemType.ATTRACTION, title: '人骨教堂', location: 'Sedlec Ossuary', region: 'kutna_hora' },
  { id: '13', date: '2025-12-07', time: '11:00', type: ItemType.ATTRACTION, title: '聖母升天與聖若翰洗者教堂', location: 'Cathedral of Assumption of Our Lady and St. John the Baptist', region: 'kutna_hora' },
  { id: '14', date: '2025-12-07', time: '11:00', type: ItemType.ATTRACTION, title: 'Muzeum Lega', location: 'Museum of Bricks Kutná Hora', region: 'kutna_hora' },
  { id: '15', date: '2025-12-07', time: '12:00', type: ItemType.SHOPPING, title: '超市｜Kaufland', location: 'Kaufland Kutná Hora', region: 'kutna_hora' },
  { id: '16', date: '2025-12-07', time: '13:00', type: ItemType.FOOD, title: '餐廳｜Pizzerie U Šneka Pohodáře', location: 'Pizzerie U Šneka Pohodáře', region: 'kutna_hora' },
  { id: '17', date: '2025-12-07', time: '14:00', type: ItemType.SHOPPING, title: '伴手禮｜Chocolate Museum', location: 'Choco-Museum Kutná Hora', region: 'kutna_hora' },
  { id: '18', date: '2025-12-07', time: '15:00', type: ItemType.ATTRACTION, title: '聖巴巴拉教堂', location: 'St Barbara\'s Cathedral', region: 'kutna_hora' },
  { id: '19', date: '2025-12-07', time: '16:00', type: ItemType.TRANSPORT, title: '火車｜庫特納霍拉 > 布拉格', location: 'Prague Main Station', region: 'moving' },
  { id: '20', date: '2025-12-07', time: '19:00', type: ItemType.FOOD, title: '餐廳｜Restaurace Hybernská', location: 'Restaurace Hybernská', region: 'prague' },
  { id: '21', date: '2025-12-07', time: '20:30', type: ItemType.ATTRACTION, title: '聖誕市集｜共和廣場', location: 'Republic Square, Prague', region: 'prague' },
  { id: '22', date: '2025-12-07', time: '21:30', type: ItemType.SHOPPING, title: '超市｜Lidl', location: 'Lidl Prague', region: 'prague' },
  // Dec 8
  { id: '23', date: '2025-12-08', time: '09:00', type: ItemType.ATTRACTION, title: '聖維特主教座堂', location: 'St. Vitus Cathedral', region: 'prague' },
  { id: '24', date: '2025-12-08', time: '09:30', type: ItemType.ATTRACTION, title: '舊皇宮', location: 'Old Royal Palace', region: 'prague' },
  { id: '25', date: '2025-12-08', time: '10:00', type: ItemType.ATTRACTION, title: '聖喬治大殿', location: 'St. George\'s Basilica', region: 'prague' },
  { id: '26', date: '2025-12-08', time: '10:30', type: ItemType.ATTRACTION, title: '黃金巷', location: 'Golden Lane', region: 'prague' },
  { id: '27', date: '2025-12-08', time: '11:00', type: ItemType.FOOD, title: '咖啡廳｜星巴克 (城堡區)', location: 'Starbucks Prague Castle', region: 'prague' },
  { id: '28', date: '2025-12-08', time: '12:00', type: ItemType.FOOD, title: '餐廳｜U Glaubiců', location: 'U Glaubiců', region: 'prague' },
  { id: '29', date: '2025-12-08', time: '13:30', type: ItemType.FOOD, title: '點心｜Café U Kajetána', location: 'Café U Kajetána', region: 'prague' },
  { id: '30', date: '2025-12-08', time: '14:00', type: ItemType.ATTRACTION, title: '聖尼古拉教堂', location: 'St. Nicholas Church', region: 'prague' },
  { id: '31', date: '2025-12-08', time: '15:00', type: ItemType.FOOD, title: '點心｜Tradiční Staropražské', location: 'Tradiční Staropražské', region: 'prague' },
  { id: '32', date: '2025-12-08', time: '15:30', type: ItemType.ATTRACTION, title: '老城橋塔 (日落)', location: 'Old Town Bridge Tower', region: 'prague' },
  { id: '33', date: '2025-12-08', time: '15:30', type: ItemType.ATTRACTION, title: '查理大橋', location: 'Charles Bridge', region: 'prague' },
  { id: '34', date: '2025-12-08', time: '17:00', type: ItemType.ATTRACTION, title: '克萊門特學院圖書館', location: 'Klementinum Library', region: 'prague' },
  { id: '35', date: '2025-12-08', time: '18:30', type: ItemType.FOOD, title: '餐廳｜Pasta Fresca', location: 'Pasta Fresca', region: 'prague' },
  { id: '36', date: '2025-12-08', time: '20:30', type: ItemType.ATTRACTION, title: '聖誕市集｜瓦茲拉夫廣場', location: 'Wenceslas Square', region: 'prague' },
  // Dec 9
  { id: '37', date: '2025-12-09', time: '08:00', type: ItemType.FOOD, title: '咖啡店｜IPPA Café', location: 'IPPA Café Jungmannova', region: 'prague' },
  { id: '38', date: '2025-12-09', time: '09:00', type: ItemType.ATTRACTION, title: '卡夫卡頭像', location: 'Franz Kafka - Rotating Head', region: 'prague' },
  { id: '39', date: '2025-12-09', time: '09:30', type: ItemType.SHOPPING, title: '哈維爾市集', location: 'Havel Market', region: 'prague' },
  { id: '40', date: '2025-12-09', time: '10:00', type: ItemType.FOOD, title: '冰淇淋｜Crème de la Crème', location: 'Crème de la Crème', region: 'prague' },
  { id: '41', date: '2025-12-09', time: '10:30', type: ItemType.ATTRACTION, title: '泰恩教堂', location: 'Church of Our Lady before Týn', region: 'prague' },
  { id: '42', date: '2025-12-09', time: '11:00', type: ItemType.FOOD, title: '煙囪捲｜Trdelník Sweet Dreams', location: 'Trdelník Sweet Dreams', region: 'prague' },
  { id: '43', date: '2025-12-09', time: '11:00', type: ItemType.SHOPPING, title: '菠丹妮 Botanicus Ungelt', location: 'Botanicus Ungelt', region: 'prague' },
  { id: '44', date: '2025-12-09', time: '12:00', type: ItemType.ATTRACTION, title: '布拉格天文鐘', location: 'Prague Astronomical Clock', region: 'prague' },
  { id: '45', date: '2025-12-09', time: '14:00', type: ItemType.SHOPPING, title: 'Vasky Praha', location: 'Vasky Praha', region: 'prague' },
  { id: '46', date: '2025-12-09', time: '15:00', type: ItemType.FOOD, title: 'Café Imperial', location: 'Café Imperial', region: 'prague' },
  { id: '47', date: '2025-12-09', time: '16:00', type: ItemType.SHOPPING, title: '古著 THE VINTAGE PRAGUE', location: 'The Vintage Prague', region: 'prague' },
  { id: '48', date: '2025-12-09', time: '17:30', type: ItemType.SHOPPING, title: '巴黎街 Pařížská', location: 'Pařížská Street', region: 'prague' },
  { id: '49', date: '2025-12-09', time: '19:30', type: ItemType.FOOD, title: 'Restaurace Mincovna', location: 'Restaurace Mincovna', region: 'prague' },
  // Dec 10
  { id: '50', date: '2025-12-10', time: '09:00', type: ItemType.ATTRACTION, title: '跳舞的房子', location: 'Dancing House', region: 'prague' },
  { id: '51', date: '2025-12-10', time: '09:30', type: ItemType.FOOD, title: 'Artic bakehouse', location: 'Artic bakehouse', region: 'prague' },
  { id: '52', date: '2025-12-10', time: '10:00', type: ItemType.ATTRACTION, title: 'Výhled na Karlův most', location: 'Výhled na Karlův most', region: 'prague' },
  { id: '53', date: '2025-12-10', time: '11:00', type: ItemType.FOOD, title: 'Pork\'s Vodičkova', location: 'Pork\'s Vodičkova', region: 'prague' },
  { id: '54', date: '2025-12-10', time: '14:00', type: ItemType.TRANSPORT, title: '交通｜Prague > CK小鎮', location: 'Český Krumlov', region: 'moving' },
  { id: '55', date: '2025-12-10', time: '21:00', type: ItemType.FOOD, title: 'Food & Wine Bar Klika', location: 'Food & Wine Bar Klika', region: 'ck' },
  // Dec 11 - CK
  { id: '56', date: '2025-12-11', time: '09:00', type: ItemType.ATTRACTION, title: '捷克克魯姆洛夫城堡', location: 'State Castle and Chateau Český Krumlov', region: 'ck' },
  { id: '57', date: '2025-12-11', time: '10:00', type: ItemType.ATTRACTION, title: '斗篷橋', location: 'Cloak Bridge', region: 'ck' },
  { id: '58', date: '2025-12-11', time: '12:00', type: ItemType.FOOD, title: 'Papa 餐廳', location: 'Papa\'s Living Restaurant', region: 'ck' },
  { id: '59', date: '2025-12-11', time: '15:00', type: ItemType.SHOPPING, title: 'MANUFAKTURA', location: 'Manufaktura Český Krumlov', region: 'ck' },
  { id: '60', date: '2025-12-11', time: '18:00', type: ItemType.FOOD, title: 'Krčma Šatlava 地窖餐廳', location: 'Krčma Šatlava', region: 'ck' },
  // Dec 12
  { id: '61', date: '2025-12-12', time: '13:00', type: ItemType.FOOD, title: 'Hospoda Na Louži', location: 'Hospoda Na Louži', region: 'ck' },
  { id: '62', date: '2025-12-12', time: '16:30', type: ItemType.TRANSPORT, title: 'CK > Hallstatt', location: 'Hallstatt', region: 'moving' },
  // Dec 14
  { id: '63', date: '2025-12-14', time: '09:00', type: ItemType.TRANSPORT, title: 'Hallstatt > Salzburg', location: 'Salzburg Hbf', region: 'moving' },
  { id: '64', date: '2025-12-14', time: '15:30', type: ItemType.ATTRACTION, title: '莫扎特出生地', location: 'Mozart\'s Birthplace', region: 'salzburg' },
  { id: '65', date: '2025-12-14', time: '19:00', type: ItemType.ATTRACTION, title: '聖誕市集｜薩爾斯堡主教座堂', location: 'Salzburg Cathedral', region: 'salzburg' },
  // Dec 15
  { id: '66', date: '2025-12-15', time: '09:30', type: ItemType.ATTRACTION, title: '薩爾茨堡要塞', location: 'Hohensalzburg Fortress', region: 'salzburg' },
  { id: '67', date: '2025-12-15', time: '12:00', type: ItemType.ATTRACTION, title: '舊城區全景', location: 'Salzburg Old Town', region: 'salzburg' },
  { id: '68', date: '2025-12-15', time: '14:00', type: ItemType.FOOD, title: 'Zwettler\'s Wirtshaus', location: 'Zwettler\'s Wirtshaus', region: 'salzburg' },
  // Dec 16
  { id: '69', date: '2025-12-16', time: '07:10', type: ItemType.TRANSPORT, title: 'Salzburg > 國王湖', location: 'Königssee', region: 'moving' },
  { id: '70', date: '2025-12-16', time: '14:11', type: ItemType.TRANSPORT, title: 'Salzburg > 維也納', location: 'Vienna Central Station', region: 'moving' },
  { id: '71', date: '2025-12-16', time: '19:00', type: ItemType.ATTRACTION, title: '聖誕市集｜美泉宮', location: 'Schönbrunn Palace', region: 'vienna' },
  // Dec 17
  { id: '72', date: '2025-12-17', time: '10:30', type: ItemType.ATTRACTION, title: '奧地利國家圖書館', location: 'Austrian National Library', region: 'vienna' },
  { id: '73', date: '2025-12-17', time: '11:30', type: ItemType.FOOD, title: 'Figlmüller 炸豬排', location: 'Figlmüller – Restaurant Bäckerstraße', region: 'vienna' },
  { id: '74', date: '2025-12-17', time: '13:30', type: ItemType.ATTRACTION, title: '聖斯德望主教座堂', location: 'St. Stephen\'s Cathedral', region: 'vienna' },
  { id: '75', date: '2025-12-17', time: '17:00', type: ItemType.FOOD, title: 'Café Central', location: 'Café Central', region: 'vienna' },
  // Dec 18
  { id: '76', date: '2025-12-18', time: '09:00', type: ItemType.ATTRACTION, title: '美景宮上宮', location: 'Belvedere Palace', region: 'vienna' },
  { id: '77', date: '2025-12-18', time: '14:30', type: ItemType.ATTRACTION, title: '聖彼得教堂 (音樂會)', location: 'St. Peter\'s Catholic Church', region: 'vienna' },
  { id: '78', date: '2025-12-18', time: '19:30', type: ItemType.ATTRACTION, title: '金色大廳音樂會', location: 'Musikverein', region: 'vienna' },
  // Dec 19
  { id: '79', date: '2025-12-19', time: '08:00', type: ItemType.ATTRACTION, title: '百水公寓', location: 'Hundertwasser House', region: 'vienna' },
  { id: '80', date: '2025-12-19', time: '17:55', type: ItemType.FLIGHT, title: '起飛｜維也納', location: 'Vienna International Airport', region: 'vienna' },
];

export const DEFAULT_PACKING: PackingItem[] = [
  { id: 'p1', text: '護照 & 簽證', completed: false, category: 'personal', isPacked: false, baggageType: 'carry_on' },
  { id: 'p2', text: '保暖衣物 (洋蔥式穿法)', completed: false, category: 'clothes', isPacked: false, baggageType: 'checked' },
  { id: 'p3', text: '轉接頭 (歐規)', completed: false, category: '3c', isPacked: false, baggageType: 'checked' },
  { id: 'p4', text: '個人藥品', completed: false, category: 'care', isPacked: false, baggageType: 'carry_on' },
].map(p => ({...p, completed: undefined})) as unknown as PackingItem[]; // Type cast for demo init data adjustment

export const DEFAULT_SHOPPING: TodoItem[] = [
  { id: 's1', text: '菠丹妮手工皂', completed: false },
  { id: 's2', text: '莫札特巧克力', completed: false },
  { id: 's3', text: '水晶銼刀', completed: false },
];
