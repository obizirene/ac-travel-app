import { GoogleGenAI, Type } from "@google/genai";
import { ItineraryItem } from "../types";

// Initialize the Gemini Client
// IMPORTANT: process.env.API_KEY is injected by the environment.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const geminiService = {
  /**
   * Enriches a list of itinerary items with "Guide" information.
   * Finds stories, tips, and weather forecasts.
   */
  enrichItinerary: async (items: ItineraryItem[]): Promise<ItineraryItem[]> => {
    try {
      // Limit to 10 items at a time to avoid token limits or timeouts for this demo
      const itemsToProcess = items.slice(0, 15); 
      
      const prompt = `
        I have a travel itinerary for Austria and Czech Republic in December 2025.
        For each item in the list below, acts as a "文青" (hipster/cultured) local guide.
        
        Provide a JSON response with an array of objects.
        Each object should have:
        - id: matching the input item id.
        - story: A one-sentence interesting historical fact or cultural anecdote (max 20 words).
        - tips: An array of strings. Include specific "Must Eat" dishes, "Must Buy" souvenirs, or "Reservation Required" warnings if applicable.
        - weather: A predicted weather forecast for December in this location (e.g. "Cloudy, -2°C").
        - highlight: boolean, true if this is a globally famous landmark or top-tier restaurant.

        Items:
        ${JSON.stringify(itemsToProcess.map(i => ({ id: i.id, title: i.title, location: i.location })))}
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                story: { type: Type.STRING },
                tips: { type: Type.ARRAY, items: { type: Type.STRING } },
                weather: { type: Type.STRING },
                highlight: { type: Type.BOOLEAN },
              },
            },
          },
        },
      });

      const enrichedData = JSON.parse(response.text || "[]");

      // Merge enriched data back into original items
      return items.map(item => {
        const enriched = enrichedData.find((e: any) => e.id === item.id);
        if (enriched) {
          return {
            ...item,
            guideInfo: {
              story: enriched.story,
              tips: enriched.tips,
              weather: enriched.weather,
              highlight: enriched.highlight,
            }
          };
        }
        return item;
      });

    } catch (error) {
      console.error("Gemini Enrichment Failed:", error);
      return items; // Return original on error
    }
  }
};