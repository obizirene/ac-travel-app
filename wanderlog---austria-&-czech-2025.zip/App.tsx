
import React, { useState, useEffect, useMemo } from 'react';
import { 
  MapPin, Utensils, Hotel, Camera, Train, Plane, ShoppingBag, 
  Plus, Trash2, GripVertical, Navigation, Info, Sun,
  CheckSquare, List, CreditCard, Luggage, X, Clock, FileText, Link,
  Wallet, Euro, Calculator, Calendar, Briefcase, Tag, Box
} from 'lucide-react';
import { 
  DndContext, 
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent 
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
  useSortable,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';

import { ItineraryItem, ItemType, AppState, TodoItem, ExpenseItem, PackingItem } from './types';
import { 
  INITIAL_ITINERARY, DEFAULT_PACKING, DEFAULT_SHOPPING, 
  REGION_OPTIONS, TYPE_OPTIONS, PACKING_CATEGORIES, 
  EXPENSE_CATEGORIES, PAYMENT_METHODS 
} from './constants';
import { geminiService } from './services/geminiService';

// --- Utility Components ---

const Badge = ({ text, colorClass }: { text: string, colorClass: string }) => (
  <span className={`px-2 py-0.5 text-xs rounded-full border ${colorClass} font-medium tracking-wide whitespace-nowrap`}>
    {text}
  </span>
);

const IconButton = ({ onClick, icon: Icon, className = "" }: any) => (
  <button onClick={onClick} className={`p-2 rounded-full hover:bg-black/5 transition-colors ${className}`}>
    <Icon size={18} />
  </button>
);

// --- Modals ---

const ModalWrapper = ({ children, onClose, title }: { children: React.ReactNode, onClose: () => void, title: string }) => (
  <div className="fixed inset-0 z-[60] flex items-end sm:items-center justify-center bg-black/50 backdrop-blur-sm sm:p-4 animate-fade-in">
    <div className="bg-white w-full sm:max-w-md sm:rounded-2xl rounded-t-2xl shadow-2xl max-h-[90vh] overflow-y-auto flex flex-col animate-slide-up">
      <div className="p-4 border-b sticky top-0 bg-white z-10 flex justify-between items-center shrink-0">
        <h3 className="font-serif text-xl font-bold text-ink">{title}</h3>
        <button onClick={onClose} className="p-1 rounded-full hover:bg-gray-100"><X size={20} className="text-gray-400" /></button>
      </div>
      <div className="p-6">
        {children}
      </div>
    </div>
  </div>
);

const AddItineraryModal = ({ 
  isOpen, 
  onClose, 
  onSave, 
  initialDate 
}: { 
  isOpen: boolean, 
  onClose: () => void, 
  onSave: (item: any, linkedTodos: string[], linkedShopping: string[]) => void,
  initialDate: string
}) => {
  const [formData, setFormData] = useState({
    time: '09:00',
    title: '',
    type: ItemType.ATTRACTION,
    region: 'prague',
    location: '',
    openTime: '',
    description: '',
    date: initialDate
  });

  const [newTodos, setNewTodos] = useState<string[]>([]);
  const [newShopping, setNewShopping] = useState<string[]>([]);
  const [tempInput, setTempInput] = useState('');

  useEffect(() => {
    if (isOpen) {
      setFormData(prev => ({ ...prev, date: initialDate }));
      setNewTodos([]);
      setNewShopping([]);
    }
  }, [isOpen, initialDate]);

  if (!isOpen) return null;

  const handleAddToList = (listType: 'todo' | 'shopping') => {
    if (!tempInput.trim()) return;
    if (listType === 'todo') setNewTodos([...newTodos, tempInput]);
    else setNewShopping([...newShopping, tempInput]);
    setTempInput('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData, newTodos, newShopping);
    onClose();
  };

  return (
    <ModalWrapper onClose={onClose} title="新增行程">
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* ... same itinerary form ... */}
          <div className="flex gap-3">
             <div className="flex-1">
              <label className="text-xs font-bold text-gray-500 uppercase mb-1 block">日期</label>
              <input 
                type="date" 
                required
                className="w-full p-3 bg-gray-50 rounded-xl border border-gray-200 focus:ring-2 focus:ring-ink outline-none"
                value={formData.date}
                onChange={e => setFormData({...formData, date: e.target.value})}
              />
            </div>
            <div className="w-1/3">
              <label className="text-xs font-bold text-gray-500 uppercase mb-1 block">時間</label>
              <input 
                type="time" 
                required
                className="w-full p-3 bg-gray-50 rounded-xl border border-gray-200 focus:ring-2 focus:ring-ink outline-none"
                value={formData.time}
                onChange={e => setFormData({...formData, time: e.target.value})}
              />
            </div>
          </div>

          <div className="flex gap-3">
            <div className="flex-1">
              <label className="text-xs font-bold text-gray-500 uppercase mb-1 block">地區</label>
              <select 
                className="w-full p-3 bg-gray-50 rounded-xl border border-gray-200 outline-none"
                value={formData.region}
                onChange={e => setFormData({...formData, region: e.target.value})}
              >
                {REGION_OPTIONS.map(opt => <option key={opt.id} value={opt.id}>{opt.label}</option>)}
              </select>
            </div>
            <div className="flex-1">
              <label className="text-xs font-bold text-gray-500 uppercase mb-1 block">類型</label>
              <select 
                className="w-full p-3 bg-gray-50 rounded-xl border border-gray-200 outline-none"
                value={formData.type}
                onChange={e => setFormData({...formData, type: e.target.value as ItemType})}
              >
                {TYPE_OPTIONS.map(opt => <option key={opt.id} value={opt.id}>{opt.label}</option>)}
              </select>
            </div>
          </div>

          <div>
            <label className="text-xs font-bold text-gray-500 uppercase mb-1 block">標題</label>
            <input 
              type="text" 
              required
              placeholder="例如：布拉格城堡"
              className="w-full p-3 bg-gray-50 rounded-xl border border-gray-200 outline-none"
              value={formData.title}
              onChange={e => setFormData({...formData, title: e.target.value})}
            />
          </div>

          <div>
            <label className="text-xs font-bold text-gray-500 uppercase mb-1 block">地點 (Google Maps)</label>
            <div className="relative">
              <MapPin size={16} className="absolute left-3 top-3.5 text-gray-400" />
              <input 
                type="text" 
                required
                placeholder="輸入地點名稱"
                className="w-full p-3 pl-9 bg-gray-50 rounded-xl border border-gray-200 outline-none"
                value={formData.location}
                onChange={e => setFormData({...formData, location: e.target.value})}
              />
            </div>
          </div>

           <div className="flex gap-3">
             <div className="flex-1">
               <label className="text-xs font-bold text-gray-500 uppercase mb-1 block">營業時間</label>
               <input 
                 type="text" 
                 placeholder="例如：09:00 - 18:00"
                 className="w-full p-3 bg-gray-50 rounded-xl border border-gray-200 outline-none"
                 value={formData.openTime}
                 onChange={e => setFormData({...formData, openTime: e.target.value})}
               />
             </div>
           </div>

           <div>
             <label className="text-xs font-bold text-gray-500 uppercase mb-1 block">備註</label>
             <textarea 
               rows={2}
               className="w-full p-3 bg-gray-50 rounded-xl border border-gray-200 outline-none text-sm"
               value={formData.description}
               onChange={e => setFormData({...formData, description: e.target.value})}
             />
           </div>

           <div className="border-t border-gray-100 pt-4">
             <h4 className="font-bold text-sm text-ink mb-2 flex items-center gap-2">
               <Link size={14} /> 關聯項目
             </h4>
             
             <div className="flex gap-2 mb-3">
               <input 
                 type="text"
                 placeholder="輸入項目..."
                 className="flex-1 p-2 bg-gray-50 rounded-lg border border-gray-200 text-sm outline-none"
                 value={tempInput}
                 onChange={e => setTempInput(e.target.value)}
               />
               <button type="button" onClick={() => handleAddToList('shopping')} className="px-3 py-1 bg-rose-100 text-rose-700 rounded-lg text-xs font-bold">購物</button>
               <button type="button" onClick={() => handleAddToList('todo')} className="px-3 py-1 bg-indigo-100 text-indigo-700 rounded-lg text-xs font-bold">待辦</button>
             </div>

             <div className="flex flex-wrap gap-2">
               {newShopping.map((item, i) => (
                 <span key={`s-${i}`} className="inline-flex items-center gap-1 px-2 py-1 bg-rose-50 text-rose-700 text-xs rounded border border-rose-100">
                   <ShoppingBag size={10} /> {item} <X size={10} className="cursor-pointer" onClick={() => setNewShopping(prev => prev.filter((_, idx) => idx !== i))} />
                 </span>
               ))}
               {newTodos.map((item, i) => (
                 <span key={`t-${i}`} className="inline-flex items-center gap-1 px-2 py-1 bg-indigo-50 text-indigo-700 text-xs rounded border border-indigo-100">
                   <CheckSquare size={10} /> {item} <X size={10} className="cursor-pointer" onClick={() => setNewTodos(prev => prev.filter((_, idx) => idx !== i))} />
                 </span>
               ))}
             </div>
           </div>

           <button type="submit" className="w-full py-3 bg-ink text-white font-bold rounded-xl shadow-lg hover:bg-gray-800 transition-all mt-4">
             確認新增
           </button>
        </form>
    </ModalWrapper>
  );
};

const AddTodoModal = ({ 
  isOpen, 
  onClose, 
  onSave,
  itinerary
}: { 
  isOpen: boolean, 
  onClose: () => void, 
  onSave: (item: TodoItem) => void,
  itinerary: ItineraryItem[]
}) => {
  const [text, setText] = useState('');
  const [date, setDate] = useState('');
  const [linkedId, setLinkedId] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      id: Date.now().toString(),
      text,
      completed: false,
      completedDate: date,
      relatedItineraryId: linkedId
    });
    setText('');
    setDate('');
    setLinkedId('');
    onClose();
  };

  return (
    <ModalWrapper onClose={onClose} title="新增待辦事項">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="text-xs font-bold text-gray-500 uppercase mb-1 block">事項內容</label>
          <input 
            type="text" 
            autoFocus
            required
            className="w-full p-3 bg-gray-50 rounded-xl border border-gray-200 outline-none"
            value={text}
            onChange={e => setText(e.target.value)}
          />
        </div>
        <div>
          <label className="text-xs font-bold text-gray-500 uppercase mb-1 block">預計完成日期 (選填)</label>
          <input 
            type="date"
            className="w-full p-3 bg-gray-50 rounded-xl border border-gray-200 outline-none"
            value={date}
            onChange={e => setDate(e.target.value)}
          />
        </div>
        <div>
          <label className="text-xs font-bold text-gray-500 uppercase mb-1 block">關聯行程 (選填)</label>
          <select 
            className="w-full p-3 bg-gray-50 rounded-xl border border-gray-200 outline-none text-sm"
            value={linkedId}
            onChange={e => setLinkedId(e.target.value)}
          >
            <option value="">無關聯</option>
            {itinerary.map(i => (
              <option key={i.id} value={i.id}>{i.date} - {i.title}</option>
            ))}
          </select>
        </div>
        <button type="submit" className="w-full py-3 bg-ink text-white font-bold rounded-xl shadow-lg mt-2">新增</button>
      </form>
    </ModalWrapper>
  );
};

const AddPackingModal = ({ 
  isOpen, 
  onClose, 
  onSave 
}: { 
  isOpen: boolean, 
  onClose: () => void, 
  onSave: (item: PackingItem) => void 
}) => {
  const [formData, setFormData] = useState<Partial<PackingItem>>({
    text: '',
    category: 'clothes',
    baggageType: 'checked',
    note: ''
  });

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      id: Date.now().toString(),
      text: formData.text || '',
      category: formData.category || 'other',
      isPacked: false,
      baggageType: formData.baggageType as 'checked' | 'carry_on',
      note: formData.note
    });
    setFormData({ text: '', category: 'clothes', baggageType: 'checked', note: '' });
    onClose();
  };

  return (
    <ModalWrapper onClose={onClose} title="新增行李物品">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="text-xs font-bold text-gray-500 uppercase mb-1 block">物品名稱</label>
          <input 
            type="text" 
            required
            className="w-full p-3 bg-gray-50 rounded-xl border border-gray-200 outline-none"
            value={formData.text}
            onChange={e => setFormData({...formData, text: e.target.value})}
          />
        </div>
        <div className="flex gap-3">
          <div className="flex-1">
            <label className="text-xs font-bold text-gray-500 uppercase mb-1 block">物品類型</label>
            <select 
              className="w-full p-3 bg-gray-50 rounded-xl border border-gray-200 outline-none"
              value={formData.category}
              onChange={e => setFormData({...formData, category: e.target.value})}
            >
              {PACKING_CATEGORIES.map(c => <option key={c.id} value={c.id}>{c.label}</option>)}
            </select>
          </div>
          <div className="flex-1">
            <label className="text-xs font-bold text-gray-500 uppercase mb-1 block">放置位置</label>
            <select 
              className="w-full p-3 bg-gray-50 rounded-xl border border-gray-200 outline-none"
              value={formData.baggageType}
              onChange={e => setFormData({...formData, baggageType: e.target.value as any})}
            >
              <option value="carry_on">隨身行李</option>
              <option value="checked">託運行李</option>
            </select>
          </div>
        </div>
        <div>
          <label className="text-xs font-bold text-gray-500 uppercase mb-1 block">備註</label>
          <input 
            type="text" 
            className="w-full p-3 bg-gray-50 rounded-xl border border-gray-200 outline-none"
            value={formData.note}
            onChange={e => setFormData({...formData, note: e.target.value})}
          />
        </div>
        <button type="submit" className="w-full py-3 bg-ink text-white font-bold rounded-xl shadow-lg mt-2">新增</button>
      </form>
    </ModalWrapper>
  );
};

const AddExpenseModal = ({ 
  isOpen, 
  onClose, 
  onSave 
}: { 
  isOpen: boolean, 
  onClose: () => void, 
  onSave: (item: ExpenseItem) => void 
}) => {
  const [formData, setFormData] = useState<Partial<ExpenseItem>>({
    date: new Date().toISOString().split('T')[0],
    category: 'food',
    paymentMethod: 'cash',
    amountEUR: 0,
    feeEUR: 0,
    amountCZK: 0,
    feeCZK: 0,
    amountTWD: 0,
    feeTWD: 0,
    totalTWD: 0,
    isReconciled: false,
    timing: 'local',
    note: ''
  });

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      id: Date.now().toString(),
      date: formData.date!,
      category: formData.category!,
      paymentMethod: formData.paymentMethod!,
      amountEUR: Number(formData.amountEUR),
      feeEUR: Number(formData.feeEUR),
      amountCZK: Number(formData.amountCZK),
      feeCZK: Number(formData.feeCZK),
      amountTWD: Number(formData.amountTWD),
      feeTWD: Number(formData.feeTWD),
      totalTWD: Number(formData.totalTWD),
      isReconciled: formData.isReconciled || false,
      timing: formData.timing as 'pre_trip' | 'local',
      note: formData.note
    });
    // Reset form...
    onClose();
  };

  const handleNumChange = (field: keyof ExpenseItem, value: string) => {
    setFormData(prev => ({...prev, [field]: value}));
  };

  return (
    <ModalWrapper onClose={onClose} title="新增支出">
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Row 1: Date & Timing */}
        <div className="flex gap-3">
          <div className="flex-1">
            <label className="text-xs font-bold text-gray-500 uppercase mb-1 block">支付日期</label>
            <input type="date" required className="w-full p-2 bg-gray-50 rounded-lg border border-gray-200"
              value={formData.date} onChange={e => setFormData({...formData, date: e.target.value})} />
          </div>
          <div className="w-1/3">
             <label className="text-xs font-bold text-gray-500 uppercase mb-1 block">階段</label>
             <select className="w-full p-2 bg-gray-50 rounded-lg border border-gray-200"
               value={formData.timing} onChange={e => setFormData({...formData, timing: e.target.value as any})}>
               <option value="pre_trip">行前</option>
               <option value="local">當地</option>
             </select>
          </div>
        </div>

        {/* Row 2: Type & Method */}
        <div className="flex gap-3">
           <div className="flex-1">
             <label className="text-xs font-bold text-gray-500 uppercase mb-1 block">類型</label>
             <select className="w-full p-2 bg-gray-50 rounded-lg border border-gray-200"
               value={formData.category} onChange={e => setFormData({...formData, category: e.target.value})}>
               {EXPENSE_CATEGORIES.map(c => <option key={c.id} value={c.id}>{c.label}</option>)}
             </select>
           </div>
           <div className="flex-1">
             <label className="text-xs font-bold text-gray-500 uppercase mb-1 block">卡別/方式</label>
             <select className="w-full p-2 bg-gray-50 rounded-lg border border-gray-200"
               value={formData.paymentMethod} onChange={e => setFormData({...formData, paymentMethod: e.target.value})}>
               {PAYMENT_METHODS.map(m => <option key={m.id} value={m.id}>{m.label}</option>)}
             </select>
           </div>
        </div>

        {/* Row 3: EUR */}
        <div className="flex gap-2 items-end">
          <div className="flex-1">
            <label className="text-xs font-bold text-gray-500 uppercase mb-1 block">歐元 (EUR)</label>
            <input type="number" step="0.01" className="w-full p-2 bg-gray-50 rounded-lg border border-gray-200"
              placeholder="0.00" value={formData.amountEUR || ''} onChange={e => handleNumChange('amountEUR', e.target.value)} />
          </div>
          <div className="w-1/3">
             <label className="text-xs font-bold text-gray-400 uppercase mb-1 block">手續費</label>
             <input type="number" step="0.01" className="w-full p-2 bg-gray-50 rounded-lg border border-gray-200 text-sm"
               placeholder="0.00" value={formData.feeEUR || ''} onChange={e => handleNumChange('feeEUR', e.target.value)} />
          </div>
        </div>

        {/* Row 4: CZK */}
        <div className="flex gap-2 items-end">
          <div className="flex-1">
            <label className="text-xs font-bold text-gray-500 uppercase mb-1 block">克朗 (CZK)</label>
            <input type="number" step="0.01" className="w-full p-2 bg-gray-50 rounded-lg border border-gray-200"
              placeholder="0.00" value={formData.amountCZK || ''} onChange={e => handleNumChange('amountCZK', e.target.value)} />
          </div>
          <div className="w-1/3">
             <label className="text-xs font-bold text-gray-400 uppercase mb-1 block">手續費</label>
             <input type="number" step="0.01" className="w-full p-2 bg-gray-50 rounded-lg border border-gray-200 text-sm"
               placeholder="0.00" value={formData.feeCZK || ''} onChange={e => handleNumChange('feeCZK', e.target.value)} />
          </div>
        </div>

        {/* Row 5: TWD */}
        <div className="flex gap-2 items-end">
          <div className="flex-1">
            <label className="text-xs font-bold text-gray-500 uppercase mb-1 block">台幣 (TWD)</label>
            <input type="number" className="w-full p-2 bg-gray-50 rounded-lg border border-gray-200"
              placeholder="0" value={formData.amountTWD || ''} onChange={e => handleNumChange('amountTWD', e.target.value)} />
          </div>
          <div className="w-1/3">
             <label className="text-xs font-bold text-gray-400 uppercase mb-1 block">手續費</label>
             <input type="number" className="w-full p-2 bg-gray-50 rounded-lg border border-gray-200 text-sm"
               placeholder="0" value={formData.feeTWD || ''} onChange={e => handleNumChange('feeTWD', e.target.value)} />
          </div>
        </div>

        {/* Row 6: Total */}
        <div className="pt-2 border-t border-dashed border-gray-200">
           <label className="text-xs font-bold text-ink uppercase mb-1 block">台幣總額 (Total TWD)</label>
           <input type="number" required className="w-full p-3 bg-amber-50 rounded-lg border border-amber-200 font-bold text-lg text-ink"
             placeholder="0" value={formData.totalTWD || ''} onChange={e => handleNumChange('totalTWD', e.target.value)} />
        </div>

        {/* Row 7: Checkbox & Note */}
        <div className="flex items-center gap-2 my-2">
          <input type="checkbox" id="reconciled" className="w-4 h-4"
            checked={formData.isReconciled} onChange={e => setFormData({...formData, isReconciled: e.target.checked})} />
          <label htmlFor="reconciled" className="text-sm font-medium">已對帳 (Reconciled)</label>
        </div>
        
        <div>
           <label className="text-xs font-bold text-gray-500 uppercase mb-1 block">備註</label>
           <input type="text" className="w-full p-2 bg-gray-50 rounded-lg border border-gray-200"
             value={formData.note} onChange={e => setFormData({...formData, note: e.target.value})} />
        </div>

        <button type="submit" className="w-full py-3 bg-ink text-white font-bold rounded-xl shadow-lg mt-2">記帳</button>
      </form>
    </ModalWrapper>
  );
};

const SimpleAddModal = ({ isOpen, onClose, onSave, title }: { isOpen: boolean, onClose: () => void, onSave: (txt: string) => void, title: string }) => {
  const [val, setVal] = useState('');
  if(!isOpen) return null;
  return (
    <ModalWrapper onClose={onClose} title={title}>
      <form onSubmit={(e) => { e.preventDefault(); if(val.trim()){ onSave(val); setVal(''); onClose(); } }}>
        <input autoFocus className="w-full p-3 bg-gray-50 rounded-xl border mb-4" placeholder="項目名稱" value={val} onChange={e => setVal(e.target.value)} />
        <button className="w-full py-3 bg-ink text-white rounded-xl font-bold">新增</button>
      </form>
    </ModalWrapper>
  )
}

// --- Sortable Item Component ---

const SortableItineraryItem = ({ item, onDelete, shoppingList, todoList }: { item: ItineraryItem, onDelete: (id: string) => void, shoppingList: TodoItem[], todoList: TodoItem[] }) => {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging
  } = useSortable({ id: item.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    zIndex: isDragging ? 10 : 1,
    opacity: isDragging ? 0.8 : 1,
  };

  const getIcon = (type: ItemType) => {
    switch (type) {
      case ItemType.FLIGHT: return Plane;
      case ItemType.HOTEL: return Hotel;
      case ItemType.TRANSPORT: return Train;
      case ItemType.FOOD: return Utensils;
      case ItemType.SHOPPING: return ShoppingBag;
      case ItemType.ATTRACTION: return Camera;
      default: return MapPin;
    }
  };

  const getColors = (type: ItemType) => {
    switch (type) {
      case ItemType.FLIGHT: return 'bg-slate-100 text-slate-700 border-slate-200';
      case ItemType.TRANSPORT: return 'bg-slate-100 text-slate-700 border-slate-200';
      case ItemType.FOOD: return 'bg-orange-50 text-orange-800 border-orange-200';
      case ItemType.ATTRACTION: return 'bg-emerald-50 text-emerald-800 border-emerald-200';
      case ItemType.HOTEL: return 'bg-indigo-50 text-indigo-800 border-indigo-200';
      case ItemType.SHOPPING: return 'bg-rose-50 text-rose-800 border-rose-200';
      default: return 'bg-gray-50 text-gray-800 border-gray-200';
    }
  };

  const Icon = getIcon(item.type);
  const colorClass = getColors(item.type);
  const regionOption = REGION_OPTIONS.find(r => r.id === item.region);

  const linkedShopping = item.relatedShoppingIds 
    ? shoppingList.filter(s => item.relatedShoppingIds?.includes(s.id))
    : [];
  // Note: relatedTodoIds link to packing list in previous version, now likely to Todos. 
  // For simplicity, we assume relatedTodoIds refer to Todos in the new 'todos' state.
  // Passing todoList as prop which should be the *todos* list now.

  return (
    <div 
      ref={setNodeRef} 
      style={style}
      className={`relative mb-4 group rounded-xl border-l-4 shadow-sm bg-white p-4 flex flex-col gap-3 transition-all
        ${item.type === ItemType.FOOD ? 'border-l-terracotta' : 
          item.type === ItemType.ATTRACTION ? 'border-l-sage' : 
          item.type === ItemType.HOTEL ? 'border-l-indigo-400' : 'border-l-slate-400'}
        ${item.guideInfo?.highlight ? 'ring-2 ring-yellow-400/50' : ''}
      `}
    >
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-3">
          <div {...attributes} {...listeners} className="cursor-grab active:cursor-grabbing text-gray-300 hover:text-gray-500 p-1">
            <GripVertical size={16} />
          </div>
          
          <div className={`p-2 rounded-lg ${colorClass} bg-opacity-50`}>
            <Icon size={18} />
          </div>
          
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-mono text-sm text-gray-500 font-bold">{item.time}</span>
              {regionOption && (
                <Badge text={regionOption.label} colorClass={`${regionOption.color} bg-opacity-40 border-transparent`} />
              )}
              {item.guideInfo?.weather && (
                <span className="flex items-center text-xs text-blue-400 bg-blue-50 px-1.5 rounded">
                  <Sun size={10} className="mr-1" /> {item.guideInfo.weather}
                </span>
              )}
            </div>
            <h3 className="font-bold text-gray-800 text-lg leading-tight mt-1">{item.title}</h3>
          </div>
        </div>

        <IconButton onClick={() => onDelete(item.id)} icon={Trash2} className="text-gray-300 hover:text-red-400" />
      </div>

      <div className="pl-12">
        <p className="text-sm text-gray-500 mb-2 flex items-center">
          <MapPin size={12} className="mr-1" /> {item.location}
        </p>
        
        {(item.openTime || item.description) && (
          <div className="mb-3 text-sm text-gray-600 space-y-1">
             {item.openTime && (
               <p className="flex items-center text-xs text-gray-400">
                 <Clock size={10} className="mr-1" /> {item.openTime}
               </p>
             )}
             {item.description && (
               <p className="line-clamp-2">{item.description}</p>
             )}
          </div>
        )}

        {(linkedShopping.length > 0) && (
          <div className="flex gap-2 mb-3">
            <span className="inline-flex items-center text-xs bg-rose-50 text-rose-600 px-2 py-0.5 rounded-md border border-rose-100">
              <ShoppingBag size={10} className="mr-1" /> 
              {linkedShopping.length} 待購
            </span>
          </div>
        )}

        {item.guideInfo && (
          <div className="mt-2 p-3 bg-stone-50 rounded-lg border border-stone-100 text-sm">
            {item.guideInfo.story && (
              <p className="italic text-stone-600 mb-2 font-serif">"{item.guideInfo.story}"</p>
            )}
            {item.guideInfo.tips && item.guideInfo.tips.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {item.guideInfo.tips.map((tip, idx) => (
                  <Badge key={idx} text={tip} colorClass="bg-yellow-100 text-yellow-800 border-yellow-200" />
                ))}
              </div>
            )}
          </div>
        )}

        <div className="mt-3 flex gap-2">
          <a 
            href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(item.location)}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center px-4 py-1.5 bg-ink text-white text-xs rounded-full shadow-lg hover:bg-gray-700 transition-all"
          >
            <Navigation size={12} className="mr-1.5" /> 導航
          </a>
        </div>
      </div>
    </div>
  );
};

// --- Main App Component ---

const App = () => {
  const [activeTab, setActiveTab] = useState<'itinerary' | 'utils'>('itinerary');
  const [utilTab, setUtilTab] = useState<'todo' | 'packing' | 'shopping' | 'expenses'>('todo');
  
  // Data State
  const [itinerary, setItinerary] = useState<ItineraryItem[]>(() => {
    const saved = localStorage.getItem('wanderlog_itinerary');
    return saved ? JSON.parse(saved) : INITIAL_ITINERARY;
  });

  const [shoppingList, setShoppingList] = useState<TodoItem[]>(() => {
    const saved = localStorage.getItem('wanderlog_shopping');
    return saved ? JSON.parse(saved) : DEFAULT_SHOPPING;
  });
  
  const [packingList, setPackingList] = useState<PackingItem[]>(() => {
    const saved = localStorage.getItem('wanderlog_packing');
    return saved ? JSON.parse(saved) : DEFAULT_PACKING;
  });
  
  const [todos, setTodos] = useState<TodoItem[]>(() => {
    const saved = localStorage.getItem('wanderlog_todos');
    return saved ? JSON.parse(saved) : [];
  });

  const [expenses, setExpenses] = useState<ExpenseItem[]>(() => {
    const saved = localStorage.getItem('wanderlog_expenses');
    return saved ? JSON.parse(saved) : [];
  });
  
  const [selectedDate, setSelectedDate] = useState<string>('2025-12-06');
  const [isEnriching, setIsEnriching] = useState(false);
  
  // Modal States
  const [showAddItinerary, setShowAddItinerary] = useState(false);
  const [showAddTodo, setShowAddTodo] = useState(false);
  const [showAddPacking, setShowAddPacking] = useState(false);
  const [showAddShopping, setShowAddShopping] = useState(false);
  const [showAddExpense, setShowAddExpense] = useState(false);

  // Persistence
  useEffect(() => {
    localStorage.setItem('wanderlog_itinerary', JSON.stringify(itinerary));
    localStorage.setItem('wanderlog_shopping', JSON.stringify(shoppingList));
    localStorage.setItem('wanderlog_packing', JSON.stringify(packingList));
    localStorage.setItem('wanderlog_todos', JSON.stringify(todos));
    localStorage.setItem('wanderlog_expenses', JSON.stringify(expenses));
  }, [itinerary, shoppingList, packingList, todos, expenses]);

  const uniqueDates = useMemo(() => {
    const dates = Array.from(new Set(itinerary.map(i => i.date))).sort();
    return dates;
  }, [itinerary]);

  const currentDayItems = useMemo(() => {
    return itinerary
      .filter(i => i.date === selectedDate)
      .sort((a, b) => a.time.localeCompare(b.time));
  }, [itinerary, selectedDate]);

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 5 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates })
  );

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    if (active.id !== over?.id) {
      setItinerary((items) => {
        const oldIndex = items.findIndex((i) => i.id === active.id);
        const newIndex = items.findIndex((i) => i.id === over?.id);
        return arrayMove(items, oldIndex, newIndex);
      });
    }
  };

  const deleteItem = (id: string) => {
    if (window.confirm("確定要刪除這個行程嗎?")) {
      setItinerary(prev => prev.filter(i => i.id !== id));
    }
  };

  const handleEnrich = async () => {
    setIsEnriching(true);
    const enriched = await geminiService.enrichItinerary(currentDayItems);
    setItinerary(prev => {
      return prev.map(item => {
        const found = enriched.find(e => e.id === item.id);
        return found || item;
      });
    });
    setIsEnriching(false);
  };

  const handleAddItem = (formData: any, newTodoTexts: string[], newShoppingTexts: string[]) => {
    const newTodoIds: string[] = [];
    const newShoppingIds: string[] = [];

    if (newTodoTexts.length > 0) {
      const createdTodos = newTodoTexts.map(text => ({ id: `t-${Date.now()}-${Math.random()}`, text, completed: false }));
      setTodos(prev => [...prev, ...createdTodos]); // Changed to setTodos
      createdTodos.forEach(t => newTodoIds.push(t.id));
    }

    if (newShoppingTexts.length > 0) {
      const createdShopping = newShoppingTexts.map(text => ({ id: `s-${Date.now()}-${Math.random()}`, text, completed: false }));
      setShoppingList(prev => [...prev, ...createdShopping]);
      createdShopping.forEach(s => newShoppingIds.push(s.id));
    }

    const newItem: ItineraryItem = {
      id: `new-${Date.now()}`,
      date: formData.date,
      time: formData.time,
      type: formData.type,
      title: formData.title,
      location: formData.location,
      region: formData.region,
      openTime: formData.openTime,
      description: formData.description,
      relatedShoppingIds: newShoppingIds,
      relatedTodoIds: newTodoIds
    };

    setItinerary(prev => [...prev, newItem]);
    if (!uniqueDates.includes(formData.date)) {
      setTimeout(() => setSelectedDate(formData.date), 100);
    } else {
      setSelectedDate(formData.date);
    }
  };

  const handleAddUtilityItem = () => {
    if (utilTab === 'expenses') setShowAddExpense(true);
    else if (utilTab === 'packing') setShowAddPacking(true);
    else if (utilTab === 'todo') setShowAddTodo(true);
    else setShowAddShopping(true);
  };

  const toggleListVal = (id: string, listType: 'todo'|'shopping'|'packing') => {
    if (listType === 'packing') {
      setPackingList(prev => prev.map(i => i.id === id ? {...i, isPacked: !i.isPacked} : i));
    } else if (listType === 'todo') {
      setTodos(prev => prev.map(i => i.id === id ? {...i, completed: !i.completed} : i));
    } else {
      setShoppingList(prev => prev.map(i => i.id === id ? {...i, completed: !i.completed} : i));
    }
  }

  const deleteUtilItem = (id: string, listType: 'todo'|'shopping'|'packing') => {
    if (listType === 'packing') setPackingList(prev => prev.filter(i => i.id !== id));
    else if (listType === 'todo') setTodos(prev => prev.filter(i => i.id !== id));
    else setShoppingList(prev => prev.filter(i => i.id !== id));
  }

  // Calculate Totals
  const expenseTotals = useMemo(() => {
    return expenses.reduce((acc, curr) => {
      return acc + (curr.totalTWD || 0);
    }, 0);
  }, [expenses]);

  return (
    <div className="min-h-screen bg-paper pb-24 font-sans text-ink">
      
      {/* Modals */}
      <AddItineraryModal 
        isOpen={showAddItinerary} 
        onClose={() => setShowAddItinerary(false)} 
        onSave={handleAddItem}
        initialDate={selectedDate}
      />
      
      <AddTodoModal isOpen={showAddTodo} onClose={() => setShowAddTodo(false)} itinerary={itinerary} onSave={(item) => setTodos(prev => [...prev, item])} />
      <AddPackingModal isOpen={showAddPacking} onClose={() => setShowAddPacking(false)} onSave={(item) => setPackingList(prev => [...prev, item])} />
      <SimpleAddModal isOpen={showAddShopping} onClose={() => setShowAddShopping(false)} title="新增購物項目" onSave={(text) => setShoppingList(prev => [...prev, {id: Date.now().toString(), text, completed: false}])} />
      <AddExpenseModal isOpen={showAddExpense} onClose={() => setShowAddExpense(false)} onSave={(item) => setExpenses(prev => [...prev, item])} />

      {/* Header */}
      <header className="sticky top-0 z-50 bg-paper/95 backdrop-blur-md border-b border-stone-200 px-6 py-4 flex justify-between items-center transition-all">
        <div>
          <h1 className="font-serif text-2xl font-bold tracking-tight text-ink">WanderLog</h1>
          <p className="text-xs text-gray-500 tracking-widest uppercase mt-0.5">Austria & Czech 2025</p>
        </div>
        {activeTab === 'itinerary' && (
          <button 
            onClick={handleEnrich}
            disabled={isEnriching}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-bold transition-all border
              ${isEnriching 
                ? 'bg-gray-100 text-gray-400 border-gray-100' 
                : 'bg-white text-indigo-600 border-indigo-100 shadow-sm hover:shadow-md hover:bg-indigo-50'}
            `}
          >
            {isEnriching ? 'AI 分析中...' : <><span className="text-lg">✨</span> 導遊分析</>}
          </button>
        )}
      </header>

      {/* Main Content */}
      <main className="max-w-md mx-auto animate-fade-in">
        
        {activeTab === 'itinerary' ? (
          <>
            {/* Date Selector */}
            <div className="sticky top-[73px] z-40 bg-paper border-b border-stone-100 py-3 overflow-x-auto no-scrollbar flex flex-nowrap items-center gap-2 px-4 shadow-sm">
              {uniqueDates.map(date => {
                const isSelected = date === selectedDate;
                const d = new Date(date);
                const day = d.getDate();
                const month = d.toLocaleString('default', { month: 'short' });
                const weekday = d.toLocaleString('default', { weekday: 'short' });

                return (
                  <button
                    key={date}
                    onClick={() => setSelectedDate(date)}
                    className={`flex-shrink-0 flex flex-col items-center justify-center w-[60px] h-[70px] rounded-xl transition-all border
                      ${isSelected 
                        ? 'bg-ink text-white border-ink shadow-lg scale-105' 
                        : 'bg-white text-gray-400 border-gray-100 hover:border-gray-300'
                      }`}
                  >
                    <span className="text-[10px] uppercase tracking-wider opacity-80">{month}</span>
                    <span className="text-xl font-serif font-bold leading-none my-0.5">{day}</span>
                    <span className="text-[10px] opacity-80">{weekday}</span>
                  </button>
                );
              })}
              <div className="w-4 flex-shrink-0"></div>
            </div>

            {/* Timeline */}
            <div className="p-4 min-h-[500px]">
              <DndContext 
                sensors={sensors} 
                collisionDetection={closestCenter} 
                onDragEnd={handleDragEnd}
              >
                <SortableContext 
                  items={currentDayItems.map(i => i.id)} 
                  strategy={verticalListSortingStrategy}
                >
                  {currentDayItems.length > 0 ? (
                    currentDayItems.map(item => (
                      <SortableItineraryItem 
                        key={item.id} 
                        item={item} 
                        onDelete={deleteItem}
                        shoppingList={shoppingList}
                        todoList={todos} 
                      />
                    ))
                  ) : (
                    <div className="text-center py-20 text-gray-400 flex flex-col items-center">
                      <MapPin size={48} className="mb-4 opacity-20" />
                      <p>點擊下方按鈕新增第一個行程</p>
                    </div>
                  )}
                </SortableContext>
              </DndContext>
            </div>
          </>
        ) : (
          /* Utilities Tab */
          <div className="p-4">
            <div className="flex gap-2 mb-6 bg-gray-100 p-1 rounded-xl overflow-x-auto">
              {(['todo', 'packing', 'shopping', 'expenses'] as const).map(tab => (
                <button
                  key={tab}
                  onClick={() => setUtilTab(tab)}
                  className={`flex-1 py-2 px-3 text-sm font-bold rounded-lg capitalize transition-all whitespace-nowrap
                    ${utilTab === tab ? 'bg-white text-ink shadow-sm' : 'text-gray-400 hover:text-gray-600'}
                  `}
                >
                  {tab === 'todo' ? '待辦' : tab === 'packing' ? '行李' : tab === 'shopping' ? '購物' : '支出'}
                </button>
              ))}
            </div>

            <div className="bg-white rounded-2xl shadow-sm border border-stone-100 p-4 min-h-[50vh] relative">
              <div className="flex justify-between items-center mb-6">
                <h2 className="font-serif text-2xl font-bold capitalize text-ink">
                  {utilTab} List
                </h2>
              </div>

              {utilTab === 'expenses' && (
                <div>
                   <div className="bg-gradient-to-br from-ink to-gray-800 p-4 rounded-xl text-white shadow-lg mb-6">
                     <p className="text-gray-400 text-xs font-bold uppercase tracking-wider mb-1">Total Expenses (TWD)</p>
                     <p className="font-serif text-3xl font-bold">${expenseTotals.toLocaleString()}</p>
                   </div>
                   
                   <div className="space-y-4">
                     {expenses.length === 0 ? <p className="text-gray-300 text-center py-8">無支出紀錄</p> : 
                       [...expenses].reverse().map(e => (
                         <div key={e.id} className="p-4 rounded-xl border border-gray-100 bg-gray-50 flex flex-col gap-2">
                            <div className="flex justify-between items-start">
                               <div>
                                 <h4 className="font-bold text-gray-800">{e.category}</h4>
                                 <p className="text-xs text-gray-400">{e.date}</p>
                               </div>
                               <div className="text-right">
                                 <p className="font-mono font-bold text-ink">${e.totalTWD.toLocaleString()}</p>
                                 <span className="text-[10px] bg-gray-200 text-gray-600 px-1 rounded">{e.paymentMethod}</span>
                               </div>
                            </div>
                            <div className="text-xs text-gray-500 flex gap-2">
                               {e.amountEUR > 0 && <span>€{e.amountEUR}</span>}
                               {e.amountCZK > 0 && <span>CZK {e.amountCZK}</span>}
                            </div>
                         </div>
                       ))
                     }
                   </div>
                </div>
              )}

              {utilTab === 'packing' && (
                 <ul className="space-y-2">
                   {packingList.map(item => {
                     const cat = PACKING_CATEGORIES.find(c => c.id === item.category);
                     return (
                       <li key={item.id} className="p-3 bg-white border border-gray-100 rounded-xl hover:shadow-sm flex items-center gap-3">
                         <button onClick={() => toggleListVal(item.id, 'packing')} className={`w-5 h-5 border rounded flex items-center justify-center ${item.isPacked ? 'bg-sage border-sage text-white' : 'border-gray-300'}`}>
                           {item.isPacked && <CheckSquare size={14} />}
                         </button>
                         <div className="flex-1">
                           <div className="flex items-center gap-2 mb-1">
                             <span className={`font-medium ${item.isPacked ? 'text-gray-400 line-through' : 'text-gray-800'}`}>{item.text}</span>
                             {cat && <Badge text={cat.label} colorClass={cat.color} />}
                           </div>
                           <div className="text-xs text-gray-400 flex gap-2 items-center">
                              <span className="flex items-center gap-1">
                                {item.baggageType === 'carry_on' ? <Briefcase size={12} /> : <Box size={12} />}
                                {item.baggageType === 'carry_on' ? '隨身' : '託運'}
                              </span>
                              {item.note && <span>• {item.note}</span>}
                           </div>
                         </div>
                         <IconButton onClick={() => deleteUtilItem(item.id, 'packing')} icon={Trash2} className="text-gray-300" />
                       </li>
                     );
                   })}
                 </ul>
              )}

              {utilTab === 'todo' && (
                <ul className="space-y-3">
                   {todos.map(item => (
                     <li key={item.id} className="p-3 bg-white border border-gray-100 rounded-xl flex items-center gap-3">
                        <button onClick={() => toggleListVal(item.id, 'todo')} className={`w-5 h-5 border rounded flex items-center justify-center ${item.completed ? 'bg-indigo-500 border-indigo-500 text-white' : 'border-gray-300'}`}>
                           {item.completed && <CheckSquare size={14} />}
                         </button>
                         <div className="flex-1">
                            <span className={`block font-medium ${item.completed ? 'text-gray-400 line-through' : 'text-gray-800'}`}>{item.text}</span>
                            {item.completedDate && <span className="text-xs text-green-600 flex items-center gap-1 mt-1"><Calendar size={10} /> 完成於 {item.completedDate}</span>}
                            {item.relatedItineraryId && <span className="text-xs text-indigo-400 flex items-center gap-1 mt-1"><Link size={10} /> 已關聯行程</span>}
                         </div>
                         <IconButton onClick={() => deleteUtilItem(item.id, 'todo')} icon={Trash2} className="text-gray-300" />
                     </li>
                   ))}
                </ul>
              )}

              {utilTab === 'shopping' && (
                <ul className="space-y-3">
                   {shoppingList.map(item => (
                     <li key={item.id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                        <button onClick={() => toggleListVal(item.id, 'shopping')} className={`w-5 h-5 border rounded flex items-center justify-center ${item.completed ? 'bg-rose-500 border-rose-500 text-white' : 'border-gray-300'}`}>
                           {item.completed && <CheckSquare size={14} />}
                         </button>
                         <span className={`flex-1 font-medium ${item.completed ? 'text-gray-400 line-through' : 'text-gray-800'}`}>{item.text}</span>
                         <IconButton onClick={() => deleteUtilItem(item.id, 'shopping')} icon={Trash2} className="text-gray-300" />
                     </li>
                   ))}
                </ul>
              )}
            </div>
          </div>
        )}
      </main>

      {/* Dock Bottom Nav */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-stone-200 z-50 pb-safe shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.05)]">
        <div className="flex justify-between items-center px-6 h-[60px] max-w-md mx-auto relative">
          
          <button 
            onClick={() => setActiveTab('itinerary')}
            className={`flex-1 flex flex-col items-center justify-center gap-1 h-full transition-colors 
              ${activeTab === 'itinerary' ? 'text-ink' : 'text-gray-300 hover:text-gray-400'}`}
          >
            <List size={22} strokeWidth={activeTab === 'itinerary' ? 2.5 : 2} />
            <span className="text-[10px] font-bold tracking-wide">行程</span>
          </button>

          {/* Central Add Button */}
          <div className="relative -top-6">
            <button 
              onClick={() => {
                if (activeTab === 'itinerary') setShowAddItinerary(true);
                else handleAddUtilityItem();
              }}
              className="w-14 h-14 bg-ink text-white rounded-full shadow-xl flex items-center justify-center hover:bg-gray-800 transition-transform hover:scale-105 active:scale-95 border-4 border-white"
            >
              <Plus size={28} />
            </button>
          </div>

          <button 
            onClick={() => setActiveTab('utils')}
            className={`flex-1 flex flex-col items-center justify-center gap-1 h-full transition-colors 
              ${activeTab === 'utils' ? 'text-ink' : 'text-gray-300 hover:text-gray-400'}`}
          >
            <Luggage size={22} strokeWidth={activeTab === 'utils' ? 2.5 : 2} />
            <span className="text-[10px] font-bold tracking-wide">工具</span>
          </button>
        </div>
      </nav>
      
      <style>{`
        .pb-safe { padding-bottom: env(safe-area-inset-bottom, 20px); }
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
        @keyframes slide-up {
          from { transform: translateY(100%); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }
        @keyframes fade-in {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        .animate-slide-up { animation: slide-up 0.3s ease-out forwards; }
        .animate-fade-in { animation: fade-in 0.2s ease-out forwards; }
      `}</style>
    </div>
  );
};

export default App;
